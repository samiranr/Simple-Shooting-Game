﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace GameProject
{
    /// <summary>
    /// A class for a burger
    /// </summary>
    public class Burger
    {
        #region Fields

        // graphic and drawing info
        Texture2D sprite;
        Rectangle drawRectangle;

        // burger stats
        int health = 100;
        int check=0;

        bool leftClickStarted = false;
        bool leftButtonReleased = true;

         SoundEffect BurgerShot;
         SoundEffect BurgerDeath;

        // shooting support
        bool canShoot = true;
        int elapsedCooldownTime = 0;

        // sound effect
        SoundEffect shootSound;

        #endregion

        #region Constructors

        /// <summary>
        ///  Constructs a burger
        /// </summary>
        /// <param name="contentManager">the content manager for loading content</param>
        /// <param name="spriteName">the sprite name</param>
        /// <param name="x">the x location of the center of the burger</param>
        /// <param name="y">the y location of the center of the burger</param>
        /// <param name="shootSound">the sound the burger plays when shooting</param>
        public Burger(ContentManager contentManager, string spriteName, int x, int y,
            SoundEffect shootSound)
        {
            LoadContent(contentManager, spriteName, x, y);
            this.shootSound = shootSound;
            this.BurgerShot = contentManager.Load<SoundEffect>("BurgerShot");
            
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the collision rectangle for the burger
        /// </summary>
        public Rectangle CollisionRectangle
        {
            get { return drawRectangle; }
        }

        #endregion

        #region Private properties

        /// <summary>
        /// Gets and sets the x location of the center of the burger
        /// </summary>
        private int X
        {
            get { return drawRectangle.Center.X; }
            set
            {
                drawRectangle.X = value - drawRectangle.Width / 2;

                // clamp to keep in range
                if (drawRectangle.X < 0)
                {
                    drawRectangle.X = 0;
                }
                else if (drawRectangle.X > GameConstants.WINDOW_WIDTH - drawRectangle.Width)
                {
                    drawRectangle.X = GameConstants.WINDOW_WIDTH - drawRectangle.Width;
                }
            }
        }

        /// <summary>
        /// Gets and sets the y location of the center of the burger
        /// </summary>
        private int Y
        {
            get { return drawRectangle.Center.Y; }
            set
            {
                drawRectangle.Y = value - drawRectangle.Height / 2;

                // clamp to keep in range
                if (drawRectangle.Y < 0)
                {
                    drawRectangle.Y = 0;
                }
                else if (drawRectangle.Y > GameConstants.WINDOW_HEIGHT - drawRectangle.Height)
                {
                    drawRectangle.Y = GameConstants.WINDOW_HEIGHT - drawRectangle.Height;
                }
            }
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Updates the burger's location based on mouse. Also fires 
        /// french fries as appropriate
        /// </summary>
        /// <param name="gameTime">game time</param>
        /// <param name="mouse">the current state of the mouse</param>
        public void Update(GameTime gameTime, MouseState mouse)
        {
            // burger should only respond to input if it still has health
            


            if (canShoot==false)
            {

            elapsedCooldownTime+= gameTime.ElapsedGameTime.Milliseconds;
    

                if (elapsedCooldownTime>GameConstants.BURGER_COOLDOWN_MILLISECONDS)
                {


                    canShoot = true;
                    elapsedCooldownTime = 0;
                }
                

            }



            if (health > 0)
            {


                if (mouse.LeftButton == ButtonState.Pressed)
                {
                    leftClickStarted = true;
                    leftButtonReleased = false;


                    if (canShoot == true)
                    {
                        Vector2 temp = new Vector2(mouse.X, mouse.Y);

                        canShoot = false;
                        Projectile projectile = new Projectile(ProjectileType.FrenchFries, Game1.GetProjectileSprite(0), (int)temp.X, (int)temp.Y, GameConstants.FRENCH_FRIES_PROJECTILE_SPEED);
                        Game1.AddProjectile(projectile);
                        BurgerShot.Play();

                    }
                }
                else if (mouse.LeftButton == ButtonState.Released)
                {
                    leftButtonReleased = true;
                    canShoot = true;




                    if (leftClickStarted)
                    {
                        leftClickStarted = false;

                    
                    }
                }







            }








            if (health > 0)
            {


                int tempx = drawRectangle.X;
                int tempy = drawRectangle.Y;

                tempx = mouse.X - drawRectangle.X;
                tempy = mouse.Y - drawRectangle.Y;

                if (drawRectangle.X > (800 - sprite.Width)) 

                {
                     drawRectangle.X -= 20;

                }
                else if (drawRectangle.X < 0)
                {

                    drawRectangle.X += 20;
                }
                else if (drawRectangle.Y > (600 - sprite.Height))
                {
                    drawRectangle.Y -= 20;

                }
                else if (drawRectangle.Y < 0)
                {
                    drawRectangle.Y += 20;

                }





                else
                {

                    drawRectangle.X += tempx * gameTime.ElapsedGameTime.Milliseconds / 200;
                    drawRectangle.Y += tempy * gameTime.ElapsedGameTime.Milliseconds / 200;



                }
                       





                   
            }





                // move burger using mouse

                // clamp burger in window

                // update shooting allowed
                // timer concept (for animations) introduced in Chapter 7

                // shoot if appropriate

        }

        /// <summary>
        /// Draws the burger
        /// </summary>
        /// <param name="spriteBatch">the sprite batch to use</param>
        /// 
        public void TeddyClash()
        {

            health = health - GameConstants.BEAR_DAMAGE;

        }

        public void ProjectClash()
        {

            health = health - GameConstants.TEDDY_BEAR_PROJECTILE_DAMAGE;

        }

        public int ReturnHealth()
        {

            return health;

        }


        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(sprite, drawRectangle, Color.White);
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Loads the content for the burger
        /// </summary>
        /// <param name="contentManager">the content manager to use</param>
        /// <param name="spriteName">the name of the sprite for the burger</param>
        /// <param name="x">the x location of the center of the burger</param>
        /// <param name="y">the y location of the center of the burger</param>
        private void LoadContent(ContentManager contentManager, string spriteName,
            int x, int y)
        {
            // load content and set remainder of draw rectangle
            sprite = contentManager.Load<Texture2D>(spriteName);
            drawRectangle = new Rectangle(x - sprite.Width / 2,
                y - sprite.Height / 2, sprite.Width,
                sprite.Height);
        }

        #endregion
    }
}
