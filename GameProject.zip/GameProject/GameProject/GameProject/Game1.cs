using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace GameProject
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;



        // SoundEffects

        SoundEffectInstance backgroundmusic;

        SoundEffect TeddyBounce;
        
        SoundEffect Explosion;
        SoundEffect BurgerShot;
        SoundEffect BurgerDeath;
        SoundEffect BurgerDamage;

        SpriteFont Font1;
        int check = 0;








      


        int elapsedTime = 0;
        const int CHANGE_DELAY_TIME = 1000;


        
        //Temporary variables to hold position and velocity details
        int Xloc;
        int Yloc;
        float Speed;
        float Angle;
        Vector2 Velocity;
        float Xvel;
        float Yvel;


        //Size of Window
        const int windowWidth = 800;
        const int windowHeight = 600;

        // game objects. Using inheritance would make this
        // easier, but inheritance isn't a GDD 1200 topic
        Burger burger;
        List<TeddyBear> bears = new List<TeddyBear>();
        static List<Projectile> projectiles = new List<Projectile>();
        List<Explosion> explosions = new List<Explosion>();

        // projectile and explosion sprites. Saved so they don't have to
        // be loaded every time projectiles or explosions are created
        static Texture2D frenchFriesSprite;
        static Texture2D teddyBearProjectileSprite;
        static Texture2D explosionSpriteStrip;


        // Our Burger and Teddybear 
        Burger ourBurger;
     


        Texture2D BurgerSprite;
        Texture2D TeddySprite;



        // scoring support
        int score = 0;
        string scoreString = GameConstants.SCORE_PREFIX + 0;

        // health support
        string healthString = GameConstants.HEALTH_PREFIX + 
            GameConstants.BURGER_INITIAL_HEALTH;
        bool burgerDead = false;

        // text display support
        SpriteFont font;

        // sound effects
        SoundEffect burgerDamage;
        SoundEffect burgerDeath;
        SoundEffect burgerShot;
        SoundEffect explosion;
        SoundEffect teddyBounce;
        SoundEffect teddyShot;


        


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            // set resolution
            graphics.PreferredBackBufferWidth = GameConstants.WINDOW_WIDTH;
            graphics.PreferredBackBufferHeight = GameConstants.WINDOW_HEIGHT;

            
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            RandomNumberGenerator.Initialize();

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);


            TeddyBounce = Content.Load<SoundEffect>("TeddyBounce");
            this.BurgerDeath = Content.Load<SoundEffect>("BurgerDeath");
            
            Explosion = Content.Load<SoundEffect>("ExplosionSound");
           
            BurgerDamage = Content.Load<SoundEffect>("BurgerDamage");




            // Initialize burger at appropriate location

            ourBurger = new Burger(this.Content, "burger", windowWidth / 2, windowHeight * 7/8, null);
            for (int i = 0; i < GameConstants.MAX_BEARS; i++)
            {
                SpawnBear();
            }

           

            // load audio content

            // load sprite font
            Font1 = Content.Load<SpriteFont>("Arial");

            // load projectile and explosion sprites

            teddyBearProjectileSprite = Content.Load<Texture2D>("teddybearprojectile");
            frenchFriesSprite = Content.Load<Texture2D>("frenchfries");
            explosionSpriteStrip = Content.Load<Texture2D>("explosion");

            // add initial game objects

            // set initial health and score strings
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
                Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();
            CheckBurgerKill();
           


            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;


            if (elapsedTime > CHANGE_DELAY_TIME)

            {
                // get current mouse state and update burger

                // update other game objects

                MouseState mouse = Mouse.GetState();

               

                    ourBurger.Update(gameTime, mouse);





                



                
                foreach (TeddyBear bear in bears)
                {
                    bear.Update(gameTime);
                }
                try
                {
                    foreach (Projectile projectile in projectiles)
                    {
                        projectile.Update(gameTime);
                    }
                }
               catch (InvalidOperationException e){
                   


                   }


                foreach (Explosion explosion in explosions)
                {
                    explosion.Update(gameTime);
                }

            }

            List<Projectile> prostoremove = new List<Projectile>();
            List<TeddyBear> teddiestoremove = new List<TeddyBear>();
            List<Explosion> exestoremove = new List<Explosion>();

         












            List<TeddyBear> teddiestobounce = new List<TeddyBear>();


            foreach (TeddyBear bear1 in bears)
            {
                foreach (TeddyBear bear2 in bears)
                {
                    if (bear1 != bear2)
                    {
                        if (bear1.CollisionRectangle.Intersects(bear2.CollisionRectangle))
                        {

                            teddiestobounce.Add(bear1);
                            teddiestobounce.Add(bear2);
                            TeddyBounce.Play();




                        }


                    }


                }

            }


            var noDupes = teddiestobounce.Distinct().ToList();

            foreach (TeddyBear bear in noDupes)
            {


                bear.velocity.X = -bear.velocity.X;
                bear.velocity.Y = -bear.velocity.Y;


            }



            foreach (Projectile projectile in projectiles)

                    


                    {

                        if (projectile.Type == ProjectileType.TeddyBear)
                        {
                            if (projectile.CollisionRectangle.Intersects(ourBurger.CollisionRectangle))
                            {

                                prostoremove.Add(projectile);
                                ourBurger.TeddyClash();
                                BurgerDamage.Play();

                               

                            }
                        }}






            int Killed = 0;

            foreach (TeddyBear bear in bears)
                {
                   
               
                    foreach (Projectile projectile in projectiles)

                    


                    {

                        if (projectile.Type == 0)
                        {
                        if (projectile.CollisionRectangle.Intersects(bear.CollisionRectangle))
                        {
                            
                                Console.WriteLine("Yo babby");
                                explosions.Add(new Explosion(explosionSpriteStrip, bear.CollisionRectangle.X, bear.CollisionRectangle.Y));
                                Explosion.Play();

                                prostoremove.Add(projectile);
                                teddiestoremove.Add(bear);
                                Killed=Killed+1;
                                
                            }

                        }
                       }
                }





            foreach (TeddyBear bear in bears)
            {
                if (bear.CollisionRectangle.Intersects(ourBurger.CollisionRectangle)) 
                {

                    teddiestoremove.Add(bear);
                   
                    explosions.Add(new Explosion(explosionSpriteStrip, bear.CollisionRectangle.X, bear.CollisionRectangle.Y));
                    Killed = Killed + 1;
                    ourBurger.TeddyClash();
                    BurgerDamage.Play();
                    Explosion.Play();



                }


            }

            


            for (int i = 0; i < 5-bears.Count; i++)
            {
                SpawnBear();
            }



        

            foreach (Projectile projectile in prostoremove)
            {

                projectiles.Remove(projectile);


            }

            



            foreach (TeddyBear bear in teddiestoremove)
            {

                bears.Remove(bear);


            }


            foreach (Explosion explosion in explosions)
            {
                if (explosion.Finished == true)
                {
                    exestoremove.Add(explosion);

                }
            }

            foreach (Explosion explosion in exestoremove)
            {

                explosions.Remove(explosion);
            }
            // check and resolve collisions between teddy bears

            // check and resolve collisions between burger and teddy bears

            // check and resolve collisions between burger and projectiles

            // check and resolve collisions between teddy bears and projectiles

            // clean out inactive teddy bears and add new ones as necessary

            // clean out inactive projectiles

            // clean out finished explosions

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            Vector2 FontOrigin = Font1.MeasureString(ourBurger.ReturnHealth().ToString()) / 2;


            spriteBatch.DrawString(Font1, ourBurger.ReturnHealth().ToString(), GameConstants.HEALTH_LOCATION, Color.LightGreen,
        0, FontOrigin, 1.0f, SpriteEffects.None, 0.5f);

            // draw game objects
            if (ourBurger != null)
            {

                ourBurger.Draw(spriteBatch);
            }

            
            foreach (TeddyBear bear in bears)
            {
                bear.Draw(spriteBatch);
            }
            foreach (Projectile projectile in projectiles)
            {
                projectile.Draw(spriteBatch);
            }
            foreach (Explosion explosion in explosions)
            {
                explosion.Draw(spriteBatch);
            }

            // draw score and health

            spriteBatch.End();

            base.Draw(gameTime);
        }

        #region Public methods

        /// <summary>
        /// Gets the projectile sprite for the given projectile type
        /// </summary>
        /// <param name="type">the projectile type</param>
        /// <returns>the projectile sprite for the type</returns>
        public static Texture2D GetProjectileSprite(ProjectileType type)
        {
            // replace with code to return correct projectile sprite based on projectile type

         
            if (type==ProjectileType.FrenchFries)
            {
                return frenchFriesSprite;
         

            }
            else
            {

                return teddyBearProjectileSprite;

            }
        }

        /// <summary>
        /// Adds the given projectile to the game
        /// </summary>
        /// <param name="projectile">the projectile to add</param>
        /// 


        public static void RemoveProjectile(Projectile projectile)
        {

            projectiles.Remove(projectile);
        }



        public static void AddProjectile(Projectile projectile)
        {
            projectiles.Add(projectile);

        }

        #endregion

        #region Private methods

        /// <summary>
        /// Spawns a new teddy bear at a random location
        /// </summary>
        private void SpawnBear()
        {
            

            //Get Random Speed and Location for the teddy


            Xloc = GetRandomLocation(0, windowWidth - GameConstants.SPAWN_BORDER_SIZE);
            Yloc = GetRandomLocation(0, windowHeight - GameConstants.SPAWN_BORDER_SIZE);
            Speed = GameConstants.MIN_BEAR_SPEED + RandomNumberGenerator.NextFloat(GameConstants.BEAR_SPEED_RANGE);

            float pivalue = (float)Math.PI;

            Angle = RandomNumberGenerator.NextFloat(2) * pivalue;

            
            Xvel=Speed * (float)Math.Cos(Angle)*10;
            Yvel=Speed * (float)Math.Sin(Angle)*10;

            

            Vector2 Velocity = new Vector2(Xvel,Yvel);

            Console.Write("\n");
            Console.Write(Xvel);
            Console.Write(Yvel);

            

            // create new bear

            int Collision = 0;
            while (Collision == 0)
            {

                Collision = 1;

                bears.Add(new TeddyBear(this.Content, "teddybear", Xloc, Yloc, Velocity, null, null));

                for (int i = 0; i < bears.Count-1; i++)
                {
                    if (bears[i].CollisionRectangle.Intersects(bears[bears.Count-1].CollisionRectangle))
                    {

                        Collision = 1;
                        bears.RemoveAt(bears.Count-1);

                    }
                }
            }

            // make sure we don't spawn into a collision

        }

        /// <summary>
        /// Gets a random location using the given min and range
        /// </summary>
        /// <param name="min">the minimum</param>
        /// <param name="range">the range</param>
        /// <returns>the random location</returns>
        private int GetRandomLocation(int min, int range)
        {
            return min + RandomNumberGenerator.Next(range);
        }

        /// <summary>
        /// Gets a list of collision rectangles for all the objects in the game world
        /// </summary>
        /// <returns>the list of collision rectangles</returns>
        private List<Rectangle> GetCollisionRectangles()
        {
            List<Rectangle> collisionRectangles = new List<Rectangle>();
            collisionRectangles.Add(burger.CollisionRectangle);
            foreach (TeddyBear bear in bears)
            {
                collisionRectangles.Add(bear.CollisionRectangle);
            }
            foreach (Projectile projectile in projectiles)
            {
                collisionRectangles.Add(projectile.CollisionRectangle);
            }
            foreach (Explosion explosion in explosions)
            {
                collisionRectangles.Add(explosion.CollisionRectangle);
            }
            return collisionRectangles;
        }

        /// <summary>
        /// Checks to see if the burger has just been killed
        /// </summary>
        private void CheckBurgerKill()
        {
            if (ourBurger.ReturnHealth() <= 0)
            {
                if (check == 0)
                {
                    check = 1;
                    BurgerDeath.Play();



                }


            }
        }

        #endregion
    }
}
